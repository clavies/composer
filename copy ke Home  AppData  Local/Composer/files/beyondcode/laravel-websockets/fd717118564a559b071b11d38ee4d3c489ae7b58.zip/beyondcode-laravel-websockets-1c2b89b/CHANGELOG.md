# Changelog

All notable changes to `laravel-websockets` will be documented in this file

## 1.0.2 - 2018-12-06

- Fix issue with wrong namespaces

## 1.0.1 - 2018-12-04

- Remove VueJS debug mode on dashboard
- Allow setting app hosts to use when connecting via the dashboard
- Added debug mode when starting the WebSocket server

## 1.0.0 - 2018-12-04

- initial release
