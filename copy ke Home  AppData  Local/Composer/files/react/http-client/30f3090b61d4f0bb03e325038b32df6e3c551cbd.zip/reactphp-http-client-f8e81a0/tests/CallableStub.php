<?php

namespace React\Tests\HttpClient;

class CallableStub
{
    public function __invoke()
    {
    }
}
