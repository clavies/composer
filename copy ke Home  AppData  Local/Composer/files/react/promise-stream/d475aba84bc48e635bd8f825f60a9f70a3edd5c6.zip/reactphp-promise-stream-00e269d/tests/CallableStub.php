<?php

namespace React\Tests\Promise\Stream;

class CallableStub
{
    public function __invoke()
    {
    }
}
